#ifndef USER_H
#define USER_H
class User{
  public:
  	User(String);
  	String getName();
  protected:
  	String name;
}