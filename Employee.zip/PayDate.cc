#include <PayDate.h>
PayDate::PayDate(int y,int m,int d){
	year=y;
	month=m;
	day=d;
};
int PayDate::getYear(){
	return year;
};
int PayDate::getMonth(){
	return month;
};
int PayDate::getDay(){
	return day;
};
String PayDate::toString(){
	String temp="";
	temp="PayDate: "+year+"."+month+"."+"day";
};
