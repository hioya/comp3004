#include <Role.h>
 Role::Role(bool iT,bool iF,float s){
 		isTerm=iT;
 		isFull=iF;
 		salary=s;
 }
 void Role::setDate(PayDate s,PayDate e){
 	if(isTerm){
 		startDate=s;
 		endDate=e;
 	}
 	else{
 		startDate=null;
 		endDate=null;
 	}
 }
bool Role::getIsTerm(return isTerm;)
bool Role::getIsFull(return isFull;)
bool Role::applyRaise(float r){
  		if(r>1||r<=0)
  			return false;
  		if(!isTerm){
  			salary=salary*(1+r);
  			return true;
  		}
  		else
  			return false;
  	}
 	PayDate Role::getStartDate(){
 		if(isTerm){
 			return startDate;
 		}
 		else return null;
 	}
 	PayDate Role::getEndDate(){
 		 if(isTerm){
 			return endDate;
 		}
 		else return null;
 	}
 	float Role::getSalary(){
 		return salary;
 	}
 	Staff::Staff(bool iT,bool iF,float s){
 		super(iT,iF,s);
 	}
  bool Staff::Leave(PayDate start,PayDate end, float rate){
    if(isTerm||rate>1||rate<=0){
      return false;
    }
    else{
      leaveDate=start;
      returnDate=end;
      salary=salary*(1+rate);
      return true;
    }
  }
  String Staff::getType(){return "Staff";}
 	Faculty::Faculty(bool iT,float s){
 		isTerm=iT;
 		salary=s;
 		isFull=true;
 	}
bool Faculty::Leave(PayDate start,PayDate end, float rate){
    if(isTerm||rate>1||rate<=0){
      return false;
    }
    else{
      leaveDate=start;
      returnDate=end;
      salary=salary*(1+rate);
      return true;
    }
  }
  String Faculty::getType(){return "Faculty";}
 	TA::TA(float s){
 		isTerm=true;
 		salary=s;
 		isFull=true;
 	}
  String TA::getType(){return "TA";}
 	RA::RA(float s){
 		isTerm=true;
 		salary=s;
 		isFull=true; 		
 	}
  String RA::getType(){return "RA";}