#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <User.h>
#include <Role.h>
#include <Paystub.h>
class Employee:public User{
  public:
  	Employee(Role[],int,Paydate);
  	int getEmployeeNum();
  	Role* getRole();
  	int getRoleNum();
  	Paydate getPaydate();
  	void calculateSalary();
  	float getSalary();
  	void editName(String);
  	bool deleteRole(Role);
  	bool addRole(Role);
  	bool applyRaise(Role,float);
  private:
  	int employeeNum;
  	Role role[3]; 
  	Paydate paydate;
  	static int EMPLOYEE_NUM=0;
  	float salary;
  	int roleNum;
};
class PSUser{
public:
	PSUser(String);
}