#include<User.h>
User::User(String n){
	name=n;
}
String User::getName(){
	return name;
}