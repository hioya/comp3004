#include <Paystub.h>
Paystub::Paystub(PayDate pd,float gi,float d,float ni,float ytdG,float ytdD){
	PayDate=pd;
	grossIncome=gi;
	deduction=d;
	netIncome=ni;
	ytdGross=ytdG;
	ytdDeduction=ytdD;
};
PayDate Paystub::getPayDate(){return payDate};
float Paystub::getGrossIncome(){return grossIncome};
float Paystub::getDeduction(){return deduction};
float Paystub::getNetIncome(){return netIncome};
float Paystub::getytdGross(){ytdGross};
float Paystub::getytdDeduction(){ytdDeduction};
String Paystub::toString(){
	String temp="";
	temp=payDate.toString()+"\nGrossIncome: "+grossIncome+"\nDeduction: "+deduction+"\nNetIncome: "+netIncome+"\nYear-to-Date Gross: "+ytdGross+"\nYear-to-Date Deduction: "+ytdDeduction+"\n";
	return temp;
};