#ifndef PAYDATE_H
#define PAYDATE_H
class PayDate{
  public:
	PayDate(int,int,int);
	int getYear();
	int getMonth();
	int getDay();
    String toString();
  private:
  	int year;
  	int month;
  	int day;
};