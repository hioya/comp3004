#include <Employee.h>
Employee::Employee(Role roles[3],int num,Paydate pd]){
	for (int i = 0; i < num; ++i)
	{
		role[i]=roles[i];
	}
	roleNum=num;
	paydate=pd;
	employeeNum=EMPLOYEE_NUM;
	EMPLOYEE_NUM++;
	calculateSalary();
}
int Employee::getEmployeeNum(){return employeeNum;}
Role* Employee::getRole(){return role;}
int Employee::getRoleNum(){return roleNum;}
Paydate Employee::getPaydate(){return paydate;}
void Employee::calculateSalary(){
	for (int i = 0; i < roleNum; ++i)
	{
		salary=salary+role[i].getSalary();
	}
}
float Employee::getSalary(){return salary;}
void Employee::editName(String n){
	name=n;
}
bool Employee::deleteRole(Role r){
	if (roleNum==1)
	{
		return false;
	}
	else{
		for (int i = 0; i < role; ++i)
		{
			if (role[i].getType==r.getType)
			{
				/* code */
				role[i]=null;
				roleNum--;
				calculateSalary();
				return true;
			}
		}
		return false;
	}
}
bool Employee::addRole(Role r){
	if (roleNum>1)
	{
		return false;
	}
	else if (role[0].getType=="Faculty"||r.getType=="Faculty")
	{
		/* code */return false;
	}
	else{
		for (int i = 0; i < roleNum; ++i)
		{
			/* code */if (role[i].getType==r.getType)
			{
				/* code */return false;
			}
		}
		role[roleNum]=r;
		roleNum++;
		calculateSalary();
		return true;
	}
}
bool Employee::applyRaise(Role ro,float r){
	if (r>1||r<=0)
	{
		/* code */return false;
	}
	else if (ro.getIsTerm)
	{
		/* code */return false;
	}
	else{
		for (int i = 0; i < roleNum; ++i)
		{
			/* code */if (role[i].getType==ro.getType)
			{
				/* code */return role[i].applyRaise(r);
			}
		}
		return false;
	}

}
PSUser::PSUser(String n){
	super(n);
}