#ifndef PAYSTUB_H
#define PAYSTUB_H
#include <PayDate.h>
class Paystub{
  public:
  	Paystub(PayDate,float,float,float,float,float);
  	PayDate getPayDate();
  	float getGrossIncome();
  	float getDeduction();
  	float getNetIncome();
  	float getytdGross();
  	float getytdDeduction();
  	String toString();
  private:
  	PayDate payDate;
  	float grossIncome;
  	float deduction;
  	float netIncome;
  	float ytdGross;
  	float ytdDeduction;
};