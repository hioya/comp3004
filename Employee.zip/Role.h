#ifndef ROLE_H
#define ROLE_H
#include <PayDate.h>
class Role{
  public:
  	Role(bool,bool,salary);
  	void setDate(PayDate,PayDate);
  	bool applyRaise(float);
 	PayDate getStartDate();
 	PayDate getEndDate();
 	float getSalary();
 	bool getIsTerm();
 	bool getIsFull();
  protected:
  	bool isTerm;
  	bool isFull;
  	float salary;
  	PayDate startDate;
  	PayDate endDate;
};
class Staff :public Role{
  public:
  	Staff(bool,bool,salary);
  	bool Leave(PayDate,PayDate,float);
  	String getType();
  private:
  	PayDate leaveDate;
  	PayDate returnDate;
};
class Faculty:public Role{
  public:
  	Faculty(bool,salary);
  	bool Leave(PayDate,PayDate,float);
  	String getType();
  private:
  	PayDate leaveDate;
  	PayDate returnDate;
};
class TA:public Role{
  public:
  	TA(salary);
  	String getType();
};
class RA:public Role{
  public:
  	RA(salary);
  	String getType();
};